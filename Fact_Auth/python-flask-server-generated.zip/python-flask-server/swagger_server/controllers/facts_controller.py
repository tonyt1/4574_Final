import connexion
from datetime import date, datetime
from typing import List, Dict
from six import iteritems
from ..util import deserialize_date, deserialize_datetime


def get_fact_random():
    """
    Generates a random fact about a random subject
    Takes in token

    :rtype: int
    """
    return 'do some magic!'


def get_fact_subject(topic):
    """
    Generates a random fact about a particular topic
    Takes in token
    :param topic: The topic that a fact should be related to
    :type topic: str

    :rtype: int
    """
    return 'do some magic!'
